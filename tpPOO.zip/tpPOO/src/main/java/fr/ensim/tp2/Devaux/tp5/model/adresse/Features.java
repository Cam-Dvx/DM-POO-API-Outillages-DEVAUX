package fr.ensim.tp2.Devaux.tp5.model.adresse;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Features {
	ArrayList <AdresseAPI> features = new ArrayList <AdresseAPI> ();
	
	@Override
	  public String toString() {
	    return "Quote{" +
	        "type='" + features.get(0).getType() + '\'' +
	        ", value=" +  +
	        '}';
	  }
	
	public ArrayList <AdresseAPI> getFeatures() {
		return features;
	}
	
	public void setFeatures(ArrayList <AdresseAPI> features) {
		this.features = features;
	}
}
