package fr.ensim.tp2.Devaux.tp5.controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import fr.ensim.tp2.Devaux.tp5.model.adresse.AdresseAPI;
import fr.ensim.tp2.Devaux.tp5.model.adresse.Features;
import fr.ensim.tp2.Devaux.tp5.model.adresse.Geometry;
import fr.ensim.tp2.Devaux.tp5.model.adresse.Properties;
import fr.ensim.tp2.Devaux.tp5.model.meteo.Meteo;
import fr.ensim.tp2.Devaux.tp5.model.meteo.MeteoAPI;
import fr.ensim.tp2.Devaux.tp5.model.meteo.Weather;

@Controller
public class MeteoController {
	
	@PostMapping("/meteo")
	public String meteoPost(@RequestParam(name="cAdr") String adresse, Model model) {
		
		model.addAttribute("adr", adresse);
		
		RestTemplate recupAdr = new RestTemplate();
		String fooResourceUrl = "https://api-adresse.data.gouv.fr/search/?q=";
		Features response = recupAdr.getForObject(fooResourceUrl + adresse, Features.class);
        AdresseAPI adrAPI = response.getFeatures().get(0);
        Geometry geometry = adrAPI.getGeometry();
        Double lon = geometry.getCoordinates().get(0);
        Double lat = geometry.getCoordinates().get(1);
        String label = adrAPI.getProperties().getLabel();
        String code = adrAPI.getProperties().getPostcode();
        String ville = adrAPI.getProperties().getCity();
        String context = adrAPI.getProperties().getContext();
        
        model.addAttribute("lon", lon);
        model.addAttribute("lat", lat);
        model.addAttribute("lab", label);
        model.addAttribute("code", code);
        model.addAttribute("city",ville);
        model.addAttribute("contexte", context);
        
        RestTemplate recupMeteo = new RestTemplate();
		String url = "http://api.openweathermap.org/data/2.5/weather?lat="+lat+"&lon="+lon+"&units=metric&appid=ed87f66bec8d0f3351aec86a5d3035b9&lang=fr"+"";
		MeteoAPI reponse2 = recupMeteo.getForObject(url, MeteoAPI.class);
        Meteo meteo = reponse2.getMain();
        ArrayList<Weather> weather = reponse2.getWeather();
        
        float temperature = meteo.getTemp();
        float tempMin = meteo.getTemp_min();
        float tempMax= meteo.getTemp_max();
        float ressenti = meteo.getFeels_like();
        float pression = meteo.getPressure();
        float humidite = meteo.getHumidity();
        String description = weather.get(0).getDescription();
        String main = weather.get(0).getMain();
        float visibilite= reponse2.getVisibility();
        float windspeed = reponse2.getWind().getSpeed();
        float winddeg = reponse2.getWind().getDeg();
        
        model.addAttribute("temp", temperature);
        model.addAttribute("min", tempMin);
        model.addAttribute("max", tempMax);
        model.addAttribute("ress", ressenti);
        model.addAttribute("press", pression);
        model.addAttribute("hum", humidite);
        model.addAttribute("desc", description);
        model.addAttribute("main", main);
        model.addAttribute("visi", visibilite);
        model.addAttribute("speed", windspeed);
        model.addAttribute("deg", winddeg);
        
		return "meteo";
	}
}
