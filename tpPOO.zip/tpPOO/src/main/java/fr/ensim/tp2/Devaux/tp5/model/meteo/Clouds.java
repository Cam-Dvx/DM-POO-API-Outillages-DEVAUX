package fr.ensim.tp2.Devaux.tp5.model.meteo;

public class Clouds {
	private float all;


	 // Getter Methods 

	 public float getAll() {
	  return all;
	 }

	 // Setter Methods 

	 public void setAll(float all) {
	  this.all = all;
	 }
}
