package fr.ensim.tp2.Devaux.tp5.model.meteo;

public class Sys {
	private float sunrise;
	 private float sunset;


	 // Getter Methods 

	 public float getSunrise() {
	  return sunrise;
	 }

	 public float getSunset() {
	  return sunset;
	 }

	 // Setter Methods 

	 public void setSunrise(float sunrise) {
	  this.sunrise = sunrise;
	 }

	 public void setSunset(float sunset) {
	  this.sunset = sunset;
	 }
}
